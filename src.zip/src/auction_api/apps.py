from django.apps import AppConfig


class AuctionApiConfig(AppConfig):
    name = 'auction_api'

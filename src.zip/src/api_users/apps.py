from django.apps import AppConfig


class ApiUsersConfig(AppConfig):
    name = 'api_users'
